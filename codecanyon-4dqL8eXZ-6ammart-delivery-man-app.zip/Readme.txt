If you need only the changed files for mobile apps in V2.12 - Hotfix check the changed files from V2.12 to V2.12 - Hotfix folder
otherwise please use "Delivery man app" folder.

Documentation - https://6ammart.app/documentation/