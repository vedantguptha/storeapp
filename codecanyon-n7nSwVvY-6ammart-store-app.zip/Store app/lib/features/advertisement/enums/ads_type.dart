enum AdsType {
  //ignore: constant_identifier_names
  video_promotion,
  //ignore: constant_identifier_names
  store_promotion,
}