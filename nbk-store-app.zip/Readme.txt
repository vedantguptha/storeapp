If you need only the changed files for mobile apps in V2.5.1 check the change files from V2.5.0 to V2.5.1 folder
otherwise please use "Store app" folder.

Documentation - https://docs.6amtech.com/